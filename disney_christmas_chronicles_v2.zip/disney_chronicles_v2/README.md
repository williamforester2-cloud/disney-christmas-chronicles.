# Disney Christmas Chronicles V2

Installable mobile web app with 99 unique quests, 30 daily bonus objectives, photo attachments, ranks, XP, gallery, backup/import, and an optional server-backed AI photo judge.

## Publish / install

1. Upload `index.html`, `manifest.webmanifest`, `sw.js`, and both PNG icons to a static HTTPS host such as GitHub Pages or Netlify. Do **not** publish `judge-server.mjs` or any secret keys as part of the static site.
2. Open the HTTPS site in Safari on iPhone, tap Share → Add to Home Screen → Add.
3. It launches full-screen with a regular home-screen icon. A true live 2×2 iOS widget is **not** available from a PWA.
4. Quests and photos are stored in this browser's local storage. Export a save file regularly, especially after photo submissions. Browser storage is limited and can be cleared.

## Optional real AI judge

- Deploy `judge-server.mjs` separately on a Node 20+ HTTPS-capable hosting service.
- Set `OPENAI_API_KEY` in server environment only, `ALLOWED_ORIGIN` to the exact HTTPS origin of the app, and `PORT` if needed. Never expose the key in website code or the app's settings.
- In app → Setup, enter the deployed server's HTTPS base URL and turn on 'Require AI approval'.
- On a quest, attach a photo and tap Submit for AI review. Approval grants XP; rejection gives a reason and lets you retry.
- A single photo cannot prove all quests (multi-day quests, eating, multiple rides, etc.). The judge is intentionally conservative; users can disable strict mode and mark these manually.
- For a public deployment add authentication, rate limits, abuse prevention, and privacy policy before allowing untrusted users to send photos. Photos are sent to the configured server and AI provider during review.

## Notes

This is a working prototype, not a hosted service. Offline manual tracking works after the service worker has installed from an HTTPS origin. AI verification requires an internet connection and deployed backend. Photo storage currently uses localStorage; high photo counts can exceed browser quotas. Export backups and avoid uploading sensitive photos.
