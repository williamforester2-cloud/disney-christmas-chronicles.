// Optional private AI review server. Deploy on a server, NOT in the browser.
// Node 20+. Set OPENAI_API_KEY, ALLOWED_ORIGIN, PORT in server environment.
import http from 'node:http';
const port=Number(process.env.PORT||8787),origin=process.env.ALLOWED_ORIGIN||'';
http.createServer(async(req,res)=>{
 const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':origin||'null','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Vary':'Origin','Cache-Control':'no-store'};
 if(req.method==='OPTIONS'){res.writeHead(204,headers);return res.end()}
 if(req.url!=='/api/review'||req.method!=='POST'){res.writeHead(404,headers);return res.end(JSON.stringify({error:'Not found'}))}
 if(!origin||req.headers.origin!==origin){res.writeHead(403,headers);return res.end(JSON.stringify({error:'Origin not allowed'}))}
 let raw='';try{for await(const chunk of req){raw+=chunk;if(raw.length>3000000)throw Error('Too large')}
 const {questName,questDescription,image}=JSON.parse(raw);
 if(!process.env.OPENAI_API_KEY)throw Error('Server not configured');
 if(typeof questName!=='string'||typeof questDescription!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(image||''))throw Error('Invalid input');
 const prompt=`You are a fair, conservative photo evidence judge for a Disney vacation scavenger hunt. Evaluate only what the image visibly demonstrates. Quest: ${questName.slice(0,120)}. Requirements: ${questDescription.slice(0,400)}. If the quest requires multiple actions or dates not verifiable from a single image, reject with a friendly explanation of what extra proof is needed. Never infer a person's identity, age, location or private attributes. Reply ONLY as JSON with accepted boolean and reason string (under 200 characters).`;
 const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':'Bearer '+process.env.OPENAI_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4.1-mini',input:[{role:'user',content:[{type:'input_text',text:prompt},{type:'input_image',image_url:image}]}],text:{format:{type:'json_schema',name:'quest_review',strict:true,schema:{type:'object',additionalProperties:false,properties:{accepted:{type:'boolean'},reason:{type:'string'}},required:['accepted','reason']}}},max_output_tokens:150})});
 if(!response.ok)throw Error('AI provider error '+response.status);
 const data=await response.json();const output=(data.output||[]).flatMap(x=>x.content||[]).find(x=>x.type==='output_text')?.text;if(!output)throw Error('Empty AI response');const result=JSON.parse(output);res.writeHead(200,headers);res.end(JSON.stringify({accepted:!!result.accepted,reason:String(result.reason).slice(0,500)}));
 }catch(err){res.writeHead(400,headers);res.end(JSON.stringify({error:err.message}))}
}).listen(port,()=>console.log('Quest judge listening on '+port));
